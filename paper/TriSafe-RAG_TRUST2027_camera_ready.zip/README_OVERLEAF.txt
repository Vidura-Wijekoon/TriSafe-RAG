Upload this zip as a new Overleaf project.
Menu -> Compiler: XeLaTeX (required to typeset the Sinhala and Tamil queries from fonts/;
pdfLaTeX also compiles but prints [Sinhala text]/[Tamil text] markers instead).
Main document: main.tex (CAMERA-READY build: author block, ACM reference block, rights footnote, no line numbers).
Before the final upload replace the placeholders in main.tex (\setcopyright, \acmDOI, \acmISBN)
with the values from the ACM rights-form e-mail.
Supplementary material: compile main_supplement.tex as a second document (not counted in the page limit).
Tables and numbers are generated from results/*/results.json by scripts/make_tables.py;
do not edit generated/*.tex by hand.

All generated inputs present.
