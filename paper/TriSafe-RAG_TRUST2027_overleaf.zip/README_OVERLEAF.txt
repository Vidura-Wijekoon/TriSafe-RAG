Upload this zip as a new Overleaf project.
Menu -> Compiler: pdfLaTeX; Main document: main.tex (anonymous review build)
or main_named.tex (camera-ready with author block).
Tables and numbers are generated from results/*/results.json by scripts/make_tables.py;
do not edit generated/*.tex by hand.

All generated inputs present.
