Upload this zip as a new Overleaf project.
Menu -> Compiler: XeLaTeX (required to typeset the Sinhala and Tamil queries from fonts/;
pdfLaTeX also compiles but prints [Sinhala text]/[Tamil text] markers instead).
Main document: main.tex (anonymous review build, 9 pages + references) or main_named.tex (camera-ready).
Supplementary material: compile main_supplement.tex as a second document (not counted in the page limit).
Tables and numbers are generated from results/*/results.json by scripts/make_tables.py;
do not edit generated/*.tex by hand.

All generated inputs present.
